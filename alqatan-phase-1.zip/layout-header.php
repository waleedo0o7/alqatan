<html dir="<?php if (isset($_GET['dir']))   echo $_GET['dir']; ?>">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap -->
    <link href="assets/vendors/bootstrap/bootstrap.min.css" rel="stylesheet">

    <!-- Font awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.7.0/css/all.min.css" rel="stylesheet">

    <!-- datatables -->
    <link href="assets/vendors/datatables/datatables.min.css" rel="stylesheet" />

    <!-- select2 -->
    <link href="assets/vendors/select2/select2.min.css" rel="stylesheet" />

    <!-- Swiper Slider -->
    <link href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" rel="stylesheet" />

    <!-- Fancybox -->
    <link href="assets/vendors/fancybox/jquery.fancybox.min.css" rel="stylesheet" />


    <link href="https://vjs.zencdn.net/8.6.1/video-js.css" rel="stylesheet" />

    <!-- Custom -->
    <link href="assets/css/style.css" rel="stylesheet">

    <title> Home page </title>

</head>


<body>